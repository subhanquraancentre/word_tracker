# Word Tracker

This is a simple and lightweight web app that helps you track how many times you recite specific words of remembrance.  
The app is built with **HTML, CSS, and JavaScript**, and works on any browser or mobile device.

## Features
- Track recitations of:
  - Jazakallah
  - MashaAllah
  - Alhamdulillah
  - SubhanAllah
- Separate counter buttons for each word
- Reset option to clear counts
- Stores progress in your browser (data is saved even after closing)
- Mobile-friendly and easy to use

## Usage
1. Open the web app in your browser.
2. Tap the button of the word you recited.
3. Your counts will be updated instantly and saved.
4. Use the **Reset** button to clear all counters.

## Demo
(After publishing with GitHub Pages, add your live link here.)

---

✨ Built for personal use, but anyone can use it to stay consistent with daily dhikr.
